
						<div class="nav-search" id="nav-search">
							<form class="form-search" action="search" method="get">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="search-input" autocomplete="off" name = 'search' />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					
