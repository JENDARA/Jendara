<?php require('func/config.php'); ?>
<?php include('includes/front/header.php');?>

	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Connectez-vous à votre compte</h2>
						<?php

            	//process login form if submitted
            	if(isset($_POST['submit_login'])){

            		$user_email = trim($_POST['user_email']);
            		$password = trim($_POST['password']);

            		if($user->login($user_email,$password))
                {
                  //check if account is activated
                  $stmt = $db->prepare('SELECT * FROM profilemaster WHERE Email = :user_email');
                  $stmt->execute(array(
                		':user_email' => $user_email
                	));
                  while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    		          {
                    $status = $row['Status'];
										$_SESSION["username"] = $row['Email'];
										$_SESSION["Role"] = $row['Role'];
										$_SESSION["uid"] = $row['Id'];

                  }
                  if( $status=="Y")
                  {
                    //logged in return to index page
                    header('Location: index.php');
                    exit;

                  }else{
                    $user->logout();
                    $message = '
                      <div class="alert alert-danger">
                        Votre compte n\'est pas activé. Veuillez visiter votre adresse e-mail pour l\'activer.
                      </div>
                    ';
                  }

            		} else {
            			$message = '
                  <div class="alert alert-danger">
                      Mauvais nom d\'utilisateur ou mot de passe.
                  </div>
                  ';
            		}

            	}//end if submit

            	if(isset($message)){ echo $message; }
            	?>
							<form action="" method ='post'>
		            <input type="email" name ="user_email" placeholder="Adresse e-mail" value='<?php if(isset($message)){ echo $_POST['user_email'];}?>' required/>
								<input type="password" name="password" placeholder="Mot de passe" value='<?php if(isset($message)){ echo $_POST['password'];}?>' required/>
								<button type="submit" name ="submit_login" class="btn btn-default">Login</button>
							</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OU</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>Nouvelle inscription d'utilisateur!</h2>
						<?php

          	//if form has been submitted process it
          	if(isset($_POST['submit']))
            {

          		//collect form data
          		extract($_POST);

          		//very basic validation
          		if($customer_name ==''){
          			$error[] = '
                <div class="alert alert-danger">
                    S\'il vous plaît entrez votre nom.
                </div>
                ';
          		}

              if($phone ==''){
          			$error[] = '
                <div class="alert alert-danger">
                    S\'il vous plait, entrez votre numéro de téléphone.
                </div>
                ';
          		}

              if($email ==''){
          			$error[] = '
                <div class="alert alert-danger">
                    S\'il vous plaît entrez votre adresse email.
                </div>
                ';
          		}

          		if($password ==''){
          			$error[] = '
                <div class="alert alert-danger">
                    S\'il vous plaît entrer le mot de passe.
                </div>
                ';
          		}

          		if($passwordConfirm ==''){
          			$error[] = '
                <div class="alert alert-danger">
                    S\'il vous plaît confirmer le mot de passe.
                </div>
                ';
          		}

          		if($password != $passwordConfirm){
          			$error[] = '
                <div class="alert alert-danger">
                   Les mots de passe ne correspondent pas.
                </div>
                ';
          		}
              if($user->check_if_exists($email) == true){

                $error[] = '
                <div class="alert alert-danger">
                    Compte avec l\'e-mail fourni existe déjà. Merci d\'utiliser une adresse e-mail différente.
                </div>
                ';

              }


          		if(!isset($error)){
                $code = md5(uniqid(rand()));
              	$hashedpassword = $user->password_hash($password, PASSWORD_BCRYPT);
                $role = 2;
								$status = "Y";

          			try {

          				//insert into database $idnumber
          				$stmt = $db->prepare('INSERT INTO profilemaster(Name, Email, PhoneNumber, Password, Role, Status, tokenCode) VALUES (:Name, :Email, :PhoneNumber, :Password, :Role, :Status, :tokenCode)') ;
          				$stmt->execute(array(
          					':PhoneNumber' => $phone,
                    ':Name' => $customer_name,
          					':Email' => $email,
                    ':Password' => $hashedpassword,
                    ':Role' => $role,
										':Status' => $status,
                    ':tokenCode' => $code
          				));


                  $id = $user->getLastUserID();
                  $key = base64_encode($id);
  			          $id = $key;


                  $message = "<div class='alert alert-success'>
                    						<button class='close' data-dismiss='alert'>&times;</button>
                    						      <strong>Success!</strong>
                  			  		</div>";

                  ;
          		  	if(isset($message)){ echo $message; }
          				exit;

          			} catch(PDOException $e) {
          			    echo $e->getMessage();
          			}

          		}

          	}

          	if(isset($error)){
          		foreach($error as $error){
          			echo '<p class="error">'.$error.'</p>';
          		}
          	}
          	?>
						<form action="" method='post'>

							<input type="text" name ="customer_name" maxlength = '30' placeholder="Nom&prénom" value='<?php if(isset($error)){ echo $_POST['customer_name'];}?>' required/>
              <input type="tel" name ="phone" placeholder="Téléphone" value='<?php if(isset($error)){ echo $_POST['phone'];}?>' required/>
						  <input type="email" name ="email" placeholder="Adresse e-mail" value='<?php if(isset($error)){ echo $_POST['email'];}?>' required/>
							<input type="password" name="password" placeholder="Mot de passe" value='<?php if(isset($error)){ echo $_POST['password'];}?>' required/>
              <input type="password" name="passwordConfirm" placeholder="Confirmer votre mot de passe" value='<?php if(isset($error)){ echo $_POST['passwordConfirm'];}?>' required/>

							<button type="submit" name='submit' class="btn btn-default">Inscription</button>
						</form>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->

<?php include('includes/front/footer.php');?>
