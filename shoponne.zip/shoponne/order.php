<?php
//get cart items
if(isset($_SESSION['Destination'])){

  header('Location: checkout.php?err=1');

}else {
  # code...

//store cart items to orders table

  require('func/config.php');
  //if not logged in redirect to login page
  if(!$user->is_logged_in()){ header('Location: login.php'); }

  $CustomerId = $_SESSION["uid"];

  $Destination = $_SESSION['Destination'];

  //
  // check cookie exist
  if ( isset( $_COOKIE['sids']) &&  $_COOKIE['sids'] !='') {
      $aids = explode(',',$_COOKIE['sids']) ;

      // validate data
      foreach ($aids as $k => $val) {
          if (!is_numeric($val)) {
              unset($aids[$k]);
          }
      }

      $products = $user->getListProductByListIds($aids);

      // init session from cookie.
      foreach ($products as $item) {
          if (!isset($_SESSION['cart_info'][$item['id']]) ) {
              $temp = [];

              $temp['id'] = $item['id'];
              $temp['name'] = $item['name'];
              $temp['cost'] = $item['cost'];
              $temp['image'] = $item['image'];
              $temp['quantity'] = 1;  // default

              $_SESSION['cart_info'][$item['id']] = $temp;
          }
      }
  }
  //get items in cart_info
  if ( !isset($_SESSION['cart_info'])  || empty($_SESSION['cart_info']) ){
    header('Location: '.$_SERVER['HTTP_REFERER']);
  }else {
    # code...
    //echo "<pre>";print_r($_SESSION);exit();
    foreach($_SESSION['cart_info'] as $item){

      $ItemId = $item['id'];
      $ItemName = $item['name'];
      $ItemImage = $item['image'];
      $Price = $item['cost'];
      $Quantity = $item['quantity'];
      $Total = $item['cost'] * $item['quantity'];
      $DateAdded = date('Y-m-d H:i:s');//year-month-day-hour-minutes-seconds
      $cartid = date('YmdHi') . $_SESSION['uid'];
      $CustomerId = $_SESSION['uid'];
      $status = 3;
      //var_dump($cartid,$ItemId,$ItemName,$ItemImage,$Price,$Quantity,$Total,$DateAdded,$CustomerId,$Destination,$status);exit();
      //save to table
      $stmt = $db->prepare('INSERT INTO customer_orders(CartId, ItemId, Name, Image, Price, Quantity, Total, DatePlaced, CustomerId, Status) VALUES (:CartId,:ItemId, :Name, :Image, :Price, :Quantity, :Total, :DatePlaced, :CustomerId, :Status)');
      $stmt->bindParam(':CartId',$cartid);
      $stmt->bindParam(':ItemId',$ItemId);
      $stmt->bindParam(':Name',$ItemName);
      $stmt->bindParam(':Image',$ItemImage);
      $stmt->bindParam(':Price',$Price);
      $stmt->bindParam(':Quantity',$Quantity);
      $stmt->bindParam(':Total',$Total);
      $stmt->bindParam(':DatePlaced',$DateAdded);
      $stmt->bindParam(':CustomerId',$CustomerId);
      $stmt->bindParam(':Status',$status);

      $stmt->execute();
      //orders table



    }

    unset($_SESSION['cart_info']);

    header('Location: order-placed.php');

  }

}
  ?>
