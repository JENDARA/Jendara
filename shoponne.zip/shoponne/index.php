<?php
$activeHome = "active";

require('func/config.php');

$featured_products_query = "select * from shop_items";
$featured_products = $user->fetch_products($featured_products_query);

if($user->is_logged_in()){
//recommended
$similaire_en_prix = "select shop_items.* from shop_items INNER JOIN customer_orders ON shop_items.Id<>customer_orders.ItemId and shop_items.Price=customer_orders.Price  where CustomerId = ".$_SESSION["uid"]." ORDER BY DatePlaced desc LIMIT 1";
//var_dump($recommended_products_query);
$recommended_products = $user->fetch_products($similaire_en_prix);
}
// $similaire_en_category = "select shop_items.* from shop_items INNER JOIN customer_orders ON shop_items.Id<>customer_orders.ItemId and shop_items.Category=customer_orders.Category where CustomerId = ".$_SESSION["uid"]." ORDER BY customer_orders.DatePlaced desc LIMIT 1";
// echo "<pre>";print_r($similaire_en_category);exit();

// $recommended_products[1] = $user->fetch_products($similaire_en_category);


include('includes/front/header.php');

include('includes/front/slider.php');?>

<section>
    <div class="container">
        <div class="row">

            <?php include('includes/front/sidebar.php');?>

            <div class="col-sm-9 padding-right">
                <div class="features_items"><!--features_items-->
                    <h2 class="title text-center">NOUVEAUX ARTICLES</h2>
                    <!-- Loop here -->
                    <?php include('includes/front/featured-items.php');?>
                </div><!--features_items-->
                <?php if($user->is_logged_in()){?>
                <div class="features_items"><!--features_items-->
                    <h2 class="title text-center">ARTICLES RECOMMANDÉS</h2>
                    <!-- Loop here -->
                    <?php include('includes/front/recommended-items.php');?>
                </div><!--features_items-->
                <?php }?>

            </div>
        </div>
    </div>
</section>
<?php include('includes/front/footer.php');?>
