<?php require('func/config.php'); ?>
<?php
$activeContactUs = "active";
include('includes/front/header.php');?>

	 <div id="contact-page" class="container">
    	<div class="bg">
	    	<div class="row">
	    		<div class="col-sm-12">
					<h2 class="title text-center">Contactez  <strong>Nous</strong></h2>
					<div id="gmap" class="contact-map">
						<div class="mapouter"><div class="gmap_canvas"><iframe width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen id="gmap_canvas" src="https://maps.google.com/maps?q=Université+Paul+Valéry+Montpellier&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div><a href="https://www.embedgooglemap.net">embedgooglemap.net</a><style>.mapouter{overflow:hidden;height:400px;width:100%;}.gmap_canvas {background:none!important;height:400px;width:100%;}</style></div>
						
					</div>
				</div>
			</div>
    		<div class="row">
	    		<div class="col-sm-8">
	    			<div class="contact-form">

	    				<h2 class="title text-center">Contacter nous</h2>
	    				<div class="status alert alert-success" style="display: none"></div>
				    	<form id="main-contact-form" class="contact-form row" name="contact-form" method="post" action="sendemail.php">
				            <div class="form-group col-md-6">
				                <input type="text" name="name" class="form-control" required="required" placeholder="Nom" >
				            </div>
				            <div class="form-group col-md-6">
				                <input type="email" name="email" class="form-control" required="required" placeholder="Email">
				            </div>
				            <div class="form-group col-md-12">
				                <input type="text" name="subject" class="form-control" required="required" placeholder="Sujet">
				            </div>
				            <div class="form-group col-md-12">
				                <textarea name="message" id="message" required="required" class="form-control" rows="8" placeholder="Votre Message"></textarea>
				            </div>
				            <div class="form-group col-md-12">
				                <input type="submit" name="submit" class="btn btn-primary pull-right" value="Envoyer">
				            </div>
				        </form>
	    			</div>
	    		</div>
	    		<div class="col-sm-4">
	    			<div class="contact-info">
	    				<h2 class="title text-center">Contact Information</h2>
	    				<address>
								<p>YASSINE JENDARA MONTPELLIER FR</p>
								<p>Université Paul Valéry </p>
								<p>MOntpellier</p>
								<p>Mobile: +33 7 53 54 58 22</p>
								<p>Email: Yassine.jendara@gmail.Com</p>
	    				</address>
	    				<div class="social-networks">
	    					<h2 class="title text-center">Réseau sociaux</h2>
							<ul>
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-google-plus"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-youtube"></i></a>
								</li>
							</ul>
	    				</div>
	    			</div>
    			</div>
	    	</div>
    	</div>
    </div><!--/#contact-page-->
<?php include('includes/front/footer.php');?>
