<?php

require('func/config.php');

if(!$user->is_logged_in()){ header('Location: login.php'); }

include('includes/front/header.php');?>

<section id="cart_items">
    <div class="container">
      <div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Accueil</a></li>
				  <li class="active">Commande passée</li>
				</ol>
			</div>
        <div class="row">

          <?php include('includes/front/sidebar.php');?>

            <div class="col-sm-9 padding-right">
                <H2>Votre commande a été passée avec succès!<H2>
            </div>
        </div>
    </div>
</section>

<?php include('includes/front/footer.php');?>
