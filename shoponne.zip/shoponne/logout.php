<?php
//include config
require('func/config.php');

session_destroy();
//log user out
$user->logout();
//header('Refresh: 0');
if(isset($_SERVER['HTTP_REFERER'])) {
  header('Location: index.php');
  //header('Location: '.$_SERVER['HTTP_REFERER']);
} else {
  header('Location: index.php');
}
exit;
?>
