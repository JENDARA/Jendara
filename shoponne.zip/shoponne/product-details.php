<?php require('func/config.php'); ?>
<?php
	$id = trim($_GET['id']);
	$product_query = "select * from shop_items where Id = $id";
	$product = $user->fetch_products($product_query);
 ?>
<?php include('includes/front/header.php');?>

	<section>
		<div class="container">
			<div class="row">

				<?php include('includes/front/sidebar.php');?>
				<div class="col-sm-9 padding-right">
					<?php foreach ($product as $item) :?>
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img alt="product 1" src="assets/uploads/<?php echo $item['Image'];?>">
							</div>
						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<!-- <img src="assets/front/images/product-details/new" class="newarrival" alt="" /> -->
								<h2><?php echo $item['Name'];?></h2>
								<p>Web ID: <?php echo $item['Id'];?></p>
								<!-- <img src="assets/front/images/product-details/rating.png" alt="" /> -->
								<span>
									<span> <?php echo $item['Price'];?> €</span>

									<a ref="<?php echo $item['Id'];?>" class="btn btn-default add-cart-button" href="cart.php"><i class="fa fa-shopping-cart"></i>Ajouter au panier</a>
								</span>
								<p><b>Availability:</b> In Stock</p>
								<p><b>Condition:</b> New</p>
								<p><b>Brand:</b> <?php echo $user->getCategory($item['Brand']);?></p>
								<p><b>Description:</b><br> <?php echo $item['Description'];?></p>
								<!-- <a href=""><img src="assets/front/images/product-details/share.png" class="share img-responsive"  alt="" /></a> -->
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
				<?php endforeach; ?>
				<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">ARTICLES RECOMMANDÉS</h2>

						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<?php
									$produit_plus_vendu = "SELECT shop_items.*,SUM(customer_orders.Quantity) FROM `shop_items` INNER JOIN customer_orders ON shop_items.Id=customer_orders.ItemId WHERE shop_items.Category = ".$product[0]['Category']." ORDER BY ItemId desc LIMIT 1";
									$similar_products = $user->fetch_products($produit_plus_vendu);

									$produit_plus_achete = "SELECT *  FROM `shop_items` ORDER BY Price LIMIT 1";
									$similar_products[1] = $user->fetch_products($produit_plus_achete)[0];

									$produit_moin_cher = "SELECT *  FROM `shop_items` WHERE Category = ".$product[0]['Category']." ORDER BY Price LIMIT 1";
									$similar_products[2] = $user->fetch_products($produit_moin_cher)[0];
									//echo "<pre>";print_r($similar_products);exit();


								 ?>
								<div class="item active">
									<?php include('includes/front/similar-items.php');?>
									</div>
							</div>
						</div>
					</div><!--/recommended_items-->

				</div>
			</div>
		</div>
	</section>

<?php include('includes/front/footer.php');?>
